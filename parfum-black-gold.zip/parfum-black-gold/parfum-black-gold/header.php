<!doctype html>
<html <?php language_attributes(); ?>>
<head><meta charset="<?php bloginfo('charset'); ?>"><meta name="viewport" content="width=device-width, initial-scale=1"><?php wp_head(); ?></head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<div class="site-shell">
<header class="site-header"><div class="container header-inner">
<a class="brand" href="<?php echo esc_url(home_url('/')); ?>">PARFUM <span>BLACK GOLD</span></a>
<button class="menu-toggle" aria-expanded="false">منو</button>
<nav class="main-nav" aria-label="منوی اصلی"><?php wp_nav_menu(array('theme_location'=>'primary','fallback_cb'=>false)); ?></nav>
</div></header>
