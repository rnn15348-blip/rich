<?php get_header(); ?>
<main><section class="section"><div class="container">
<div class="content-box">
<div class="breadcrumbs"><a href="<?php echo esc_url(get_post_type_archive_link('pbg_product')); ?>">فروشگاه</a> / <?php the_title(); ?></div>
<div class="hero-grid">
<div><?php if(has_post_thumbnail()) the_post_thumbnail('large'); else echo '<div class="product-art"><div class="bottle"></div></div>'; ?></div>
<div><div class="eyebrow">SIGNATURE FRAGRANCE</div><h1><?php the_title(); ?></h1>
<?php $price=get_post_meta(get_the_ID(),'_price',true); $volume=get_post_meta(get_the_ID(),'_volume',true); $gender=get_post_meta(get_the_ID(),'_gender',true); ?>
<?php if($price): ?><div class="price"><?php echo esc_html(number_format_i18n((float)$price)); ?> تومان</div><?php endif; ?>
<p class="muted"><?php echo esc_html($volume); ?> ml · <?php echo esc_html($gender); ?></p>
<div class="entry-content"><?php the_content(); ?></div>
<div class="notice">این قالب عمداً بدون WooCommerce ساخته شده است؛ دکمه خرید را می‌توانید در Elementor یا بلوک‌های وردپرس به درگاه/فرم دلخواه متصل کنید.</div>
</div></div></div></div></section></main>
<?php get_footer(); ?>
