<?php get_header(); ?>
<main>
<?php if(have_posts()): while(have_posts()): the_post(); ?>
<section class="section"><div class="container content-box">
  <div class="breadcrumbs"><?php echo esc_html(get_bloginfo('name')); ?> / <?php the_title(); ?></div>
  <h1><?php the_title(); ?></h1>
  <div class="entry-content"><?php the_content(); ?></div>
</div></section>
<?php endwhile; else: ?>
<section class="section"><div class="container content-box"><h1>چیزی پیدا نشد</h1><p class="muted">محتوای موردنظر وجود ندارد.</p></div></section>
<?php endif; ?>
</main>
<?php get_footer(); ?>
