<?php get_header(); ?>
<main>
<section class="page-hero"><div class="container"><div class="breadcrumbs">خانه / فروشگاه</div><h1>فروشگاه عطر و ادکلن</h1><p class="muted">انتخابی از رایحه‌های خاص و ماندگار.</p></div></section>
<section class="section"><div class="container">
<div class="archive-toolbar"><strong><?php echo esc_html(wp_count_posts('pbg_product')->publish); ?> محصول</strong><?php get_search_form(); ?></div>
<div class="grid"><?php if(have_posts()): while(have_posts()): the_post(); pbg_product_card(get_the_ID()); endwhile; else: ?><div class="notice">هنوز محصولی ثبت نشده است.</div><?php endif; ?></div>
<?php the_posts_pagination(); ?>
</div></section></main>
<?php get_footer(); ?>
