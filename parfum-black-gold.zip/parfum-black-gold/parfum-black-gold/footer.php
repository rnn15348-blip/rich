<footer class="site-footer"><div class="container footer-grid">
<div><div class="brand">PARFUM <span>BLACK GOLD</span></div><p class="muted">تجربه‌ای لوکس برای انتخاب رایحه. تمامی متن‌ها و بخش‌ها از پیشخوان وردپرس قابل مدیریت‌اند.</p></div>
<div><div class="footer-title">دسترسی سریع</div><?php wp_nav_menu(array('theme_location'=>'footer','fallback_cb'=>false)); ?></div>
<div><div class="footer-title">راهنما</div><a href="<?php echo esc_url(home_url('/guide/')); ?>">راهنمای انتخاب عطر</a><br><a href="<?php echo esc_url(home_url('/faq/')); ?>">سوالات متداول</a></div>
<div><div class="footer-title">پشتیبانی</div><a href="<?php echo esc_url(home_url('/contact/')); ?>">تماس با ما</a><br><a href="<?php echo esc_url(home_url('/order-tracking/')); ?>">پیگیری سفارش</a></div>
</div></footer></div><?php wp_footer(); ?></body></html>
