<?php get_header(); ?>
<main><section class="section"><div class="container"><div class="content-box">
<h1>نتایج جستجو برای: <?php echo esc_html(get_search_query()); ?></h1>
<?php if(have_posts()): while(have_posts()): the_post(); ?><article style="padding:18px 0;border-bottom:1px solid var(--pline)"><h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2><div class="muted"><?php echo esc_html(wp_trim_words(get_the_excerpt(),30)); ?></div></article><?php endwhile; the_posts_pagination(); else: ?><p>نتیجه‌ای پیدا نشد.</p><?php endif; ?>
</div></div></section></main><?php get_footer(); ?>
