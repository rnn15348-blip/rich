<?php
if (!defined('ABSPATH')) exit;

define('PBG_VERSION','1.0.0');

function pbg_setup(){
  add_theme_support('title-tag');
  add_theme_support('post-thumbnails');
  add_theme_support('custom-logo');
  add_theme_support('html5', array('search-form','comment-form','comment-list','gallery','caption','style','script'));
  add_theme_support('editor-styles');
  add_theme_support('wp-block-styles');
  add_theme_support('responsive-embeds');
  register_nav_menus(array('primary'=>'منوی اصلی','footer'=>'منوی فوتر'));
}
add_action('after_setup_theme','pbg_setup');

function pbg_assets(){
  wp_enqueue_style('pbg-style',get_stylesheet_uri(),array(),PBG_VERSION);
  wp_enqueue_script('pbg-main',get_template_directory_uri().'/assets/js/main.js',array(),PBG_VERSION,true);
}
add_action('wp_enqueue_scripts','pbg_assets');

function pbg_widgets(){
  register_sidebar(array('name'=>'سایدبار اصلی','id'=>'sidebar-1','before_widget'=>'<section class="content-box">','after_widget'=>'</section>','before_title'=>'<h3>','after_title'=>'</h3>'));
}
add_action('widgets_init','pbg_widgets');

function pbg_cpts(){
  register_post_type('pbg_product',array(
    'labels'=>array('name'=>'محصولات','singular_name'=>'محصول'),
    'public'=>true,'menu_icon'=>'dashicons-cart','supports'=>array('title','editor','thumbnail','excerpt','custom-fields'),
    'has_archive'=>true,'rewrite'=>array('slug'=>'products')
  ));
  register_taxonomy('pbg_brand','pbg_product',array('label'=>'برندها','public'=>true,'hierarchical'=>false,'rewrite'=>array('slug'=>'brand')));
  register_taxonomy('pbg_note','pbg_product',array('label'=>'نت‌های عطر','public'=>true,'hierarchical'=>false,'rewrite'=>array('slug'=>'note')));
}
add_action('init','pbg_cpts');

function pbg_product_meta(){
  add_meta_box('pbg_product_info','اطلاعات فروش محصول','pbg_product_meta_box','pbg_product','normal','high');
}
add_action('add_meta_boxes','pbg_product_meta');
function pbg_product_meta_box($post){
  wp_nonce_field('pbg_save_product','pbg_product_nonce');
  $fields=array(
    'price'=>'قیمت',
    'old_price'=>'قیمت قبل',
    'volume'=>'حجم (ml)',
    'gender'=>'مناسب برای',
    'stock'=>'موجودی',
    'sku'=>'کد محصول',
    'badge'=>'برچسب',
    'rating'=>'امتیاز'
  );
  echo '<div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">';
  foreach($fields as $key=>$label){
    $v=get_post_meta($post->ID,'_'.$key,true);
    echo '<label>'.$label.'<input style="width:100%" name="pbg_'.$key.'" value="'.esc_attr($v).'"></label>';
  }
  echo '</div>';
}
function pbg_save_product($post_id){
  if(!isset($_POST['pbg_product_nonce']) || !wp_verify_nonce($_POST['pbg_product_nonce'],'pbg_save_product')) return;
  if(defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
  foreach(array('price','old_price','volume','gender','stock','sku','badge','rating') as $key){
    if(isset($_POST['pbg_'.$key])) update_post_meta($post_id,'_'.$key,sanitize_text_field($_POST['pbg_'.$key]));
  }
}
add_action('save_post_pbg_product','pbg_save_product');

function pbg_product_card($id){
  $price=get_post_meta($id,'_price',true);
  $volume=get_post_meta($id,'_volume',true);
  $badge=get_post_meta($id,'_badge',true);
  echo '<article class="card"><a href="'.esc_url(get_permalink($id)).'"><div class="product-art">';
  if(has_post_thumbnail($id)) echo get_the_post_thumbnail($id,'medium');
  else echo '<div class="mini-bottle"></div>';
  echo '</div><div class="card-body">';
  if($badge) echo '<div class="meta">'.esc_html($badge).'</div>';
  echo '<h3>'.esc_html(get_the_title($id)).'</h3>';
  if($volume) echo '<div class="meta">'.esc_html($volume).' ml</div>';
  if($price) echo '<div class="price">'.esc_html(number_format_i18n((float)$price)).' تومان</div>';
  echo '</div></a></article>';
}

function pbg_elementor_support(){
  add_theme_support('elementor');
}
add_action('after_setup_theme','pbg_elementor_support');

function pbg_block_patterns(){
  register_block_pattern_category('pbg',array('label'=>'Parfum Black Gold'));
}
add_action('init','pbg_block_patterns');

function pbg_home_shortcode(){
  ob_start(); ?>
  <div class="hero"><div class="container hero-grid"><div><div class="eyebrow">PARFUM • BLACK GOLD</div><h1>رایحه‌ای که قبل از شما وارد می‌شود.</h1><p>قالب لوکس و سریع برای فروشگاه عطر و ادکلن؛ بدون WooCommerce و با مدیریت کامل محتوا از پیشخوان.</p><a class="gold-btn" href="<?php echo esc_url(get_post_type_archive_link('pbg_product')); ?>">مشاهده عطرها</a><a class="ghost-btn" href="#collections">کالکشن‌ها</a></div><div class="hero-card"><div class="bottle"></div></div></div></div>
  <?php
  return ob_get_clean();
}
add_shortcode('pbg_home_hero','pbg_home_shortcode');

function pbg_admin_menu(){
  add_theme_page('راه‌اندازی سریع Parfum','راه‌اندازی Parfum','manage_options','pbg-setup','pbg_setup_page');
}
add_action('admin_menu','pbg_admin_menu');

function pbg_setup_page(){
  if(!current_user_can('manage_options')) return;
  if(isset($_POST['pbg_install_demo']) && check_admin_referer('pbg_setup')){
    pbg_create_demo_content();
    echo '<div class="notice notice-success"><p>نمونه اولیه، منوها و صفحات پایه ساخته/به‌روزرسانی شدند. اکنون می‌توانید آن‌ها را از پیشخوان ویرایش کنید.</p></div>';
  }
  ?>
  <div class="wrap">
    <h1>راه‌اندازی سریع Parfum Black Gold</h1>
    <p>این ابزار با یک کلیک صفحات پایه، نمونه محصولات و منوهای اولیه را ایجاد می‌کند. محتوای موجود با نام‌های متفاوت حذف نمی‌شود.</p>
    <form method="post">
      <?php wp_nonce_field('pbg_setup'); ?>
      <p><label><input type="checkbox" name="confirm" value="1" required> تأیید می‌کنم صفحات و نمونه‌های اولیه ایجاد شوند.</label></p>
      <p><button class="button button-primary" name="pbg_install_demo" value="1">ایجاد دمو و منوها</button></p>
    </form>
  </div>
  <?php
}
function pbg_get_or_create_page($title,$slug,$content=''){
  $page=get_page_by_path($slug);
  if($page) return $page->ID;
  return wp_insert_post(array('post_title'=>$title,'post_name'=>$slug,'post_content'=>$content,'post_status'=>'publish','post_type'=>'page'));
}
function pbg_create_demo_content(){
  $pages=array(
    'خانه'=>'home',
    'فروشگاه'=>'shop',
    'برندها'=>'brands',
    'درباره ما'=>'about',
    'تماس با ما'=>'contact',
    'وبلاگ'=>'blog',
    'راهنمای انتخاب عطر'=>'guide',
    'سوالات متداول'=>'faq',
    'قوانین و شرایط'=>'terms',
    'حریم خصوصی'=>'privacy',
    'پیگیری سفارش'=>'order-tracking'
  );
  $ids=array();
  foreach($pages as $title=>$slug) $ids[$slug]=pbg_get_or_create_page($title,$slug,'<!-- wp:shortcode -->[pbg_home_hero]<!-- /wp:shortcode -->');
  $home=$ids['home']; update_option('show_on_front','page'); update_option('page_on_front',$home);
  for($i=1;$i<=8;$i++){
    $pid=wp_insert_post(array('post_title'=>'عطر نمونه '.$i,'post_content'=>'توضیحات کامل و قابل ویرایش محصول نمونه شماره '.$i,'post_status'=>'publish','post_type'=>'pbg_product'));
    if($pid) {
      update_post_meta($pid,'_price',number_format(1800000+$i*125000,0,'.',''));
      update_post_meta($pid,'_volume',100);
      update_post_meta($pid,'_gender',$i%2?'زنانه':'مردانه');
      update_post_meta($pid,'_stock',20+$i);
      update_post_meta($pid,'_sku','PBG-'.str_pad($i,3,'0',STR_PAD_LEFT));
    }
  }
  $menu=wp_get_nav_menu_object('منوی اصلی');
  $menu_id=$menu ? $menu->term_id : wp_create_nav_menu('منوی اصلی');
  if($menu_id){
    $existing=wp_get_nav_menu_items($menu_id);
    $existing_titles=array();
    foreach((array)$existing as $it) $existing_titles[]=$it->title;
    foreach(array('خانه'=>'home','فروشگاه'=>'shop','برندها'=>'brands','راهنمای انتخاب عطر'=>'guide','وبلاگ'=>'blog','درباره ما'=>'about','تماس با ما'=>'contact') as $title=>$slug){
      if(!in_array($title,$existing_titles,true)) wp_update_nav_menu_item($menu_id,0,array('menu-item-title'=>$title,'menu-item-object'=>'page','menu-item-object-id'=>$ids[$slug],'menu-item-type'=>'post_type','menu-item-status'=>'publish'));
    }
    $locations=get_theme_mod('nav_menu_locations',array()); $locations['primary']=$menu_id; set_theme_mod('nav_menu_locations',$locations);
  }
}
